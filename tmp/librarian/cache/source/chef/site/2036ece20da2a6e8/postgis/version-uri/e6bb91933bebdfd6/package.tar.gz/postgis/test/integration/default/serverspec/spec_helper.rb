require 'serverspec'
require 'pathname'
require 'net/ssh'

include SpecInfra::Helper::Exec

RSpec.configure do |c|
end

