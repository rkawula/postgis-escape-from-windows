[![Build Status](https://secure.travis-ci.org/realityforge/chef-postgis.png?branch=master)](http://travis-ci.org/realityforge/chef-postgis)

The postgis cookbook installs and configures the Postgis Postgresql extension and creates a GIS enabled database template.
