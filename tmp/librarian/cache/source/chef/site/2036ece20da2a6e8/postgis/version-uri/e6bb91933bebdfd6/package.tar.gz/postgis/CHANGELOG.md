## v0.2.6:

* Added support for RHEL and derivatives using package in default repository. Submitted by Benjamin Roberts.

## v0.2.4:

* Allow for overriding the locale used with the createdb command. Submitted by Kirk True.

## v0.2.2:

* Include the keys for the packages in the cookbook. Allows the cookbook to work behind a firewall.
* Minor documentation improvements.

## v0.2.0:

* Initial release
